# Rihame Chaib — Black Portfolio

Minimal black-themed portfolio website with personal logo.

## Focus
- Mathematics Olympiad
- Programming
- Clean design

## Tech
- HTML
- CSS
- GitHub Pages

## License
MIT License
